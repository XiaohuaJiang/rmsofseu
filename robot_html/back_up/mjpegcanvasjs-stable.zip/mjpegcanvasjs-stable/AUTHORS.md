Original Authors
----------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)

Contributors
------------

