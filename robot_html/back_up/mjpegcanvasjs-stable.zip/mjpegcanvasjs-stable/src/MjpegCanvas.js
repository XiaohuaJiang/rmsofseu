/**
 * @author Russell Toris - rctoris@wpi.edu
 */

var MJPEGCANVAS = MJPEGCANVAS || {
  REVISION : '3'
};
